#include<iostream>
#include<string>

using namespace std;
class CTeacher 
{
public:
	CTeacher(string nam, string s, string tit, string ad, string t);
	void display();
protected:
	string name;string sex;string title;string address;string tel;
};
CTeacher::CTeacher(string nam, string s, string tit, string ad, string t)
	: name(nam), sex(s), title(tit), address(ad), tel(t) {};
void CTeacher::display() 
{
	cout << "������" << name << endl;
	cout << "�Ա�" << sex << endl;
	cout << "ְ�ƣ�" << title << endl;
	cout << "��ַ��" << address << endl;
	cout << "�绰��" << tel << endl;
}
//================================================
class CAdministrator 
{
protected:
	string name;
	string sex;
	string post;
	string address;
	string tel;
public:
	CAdministrator(string nam, string s, string p, string ad, string t);
	void display();
};
CAdministrator::CAdministrator(string nam,string s,string p,string ad,string t ) 
:name(nam),sex(s),post(p),address(ad),tel(t){}

void CAdministrator::display() {
	cout << "name��" << name << endl;
	cout << "sex" << sex << endl;
	cout << "post:" << post << endl;
	cout << "address:" << address << endl;
	cout << "tel:" << tel << endl;
};
//==================================================
class CTeacher_Administractor :public CTeacher, public CAdministrator
{
private:
	float wage;
public:
	CTeacher_Administractor(string nam, string s, string t, string p, string ad, string tel, float w);
	void show();
};
CTeacher_Administractor::CTeacher_Administractor(string nam, string s, string t, string p, string ad, string tel, float w)
	:CTeacher(nam, s, t, ad, tel), CAdministrator(nam, s, p, ad, tel), wage(w) {};
void CTeacher_Administractor::show() {
	CTeacher::display();
	cout << "ְ��" << CAdministrator::post << endl;
	cout << "���ʣ�" << wage << endl;
};
//------------------------------------------------------
int main()
{
	CTeacher_Administractor a("��Ӣ", "��", "�߼�", "��ʦ", "��ʦ��ĳĳ¥", "12550626563", 6800);
	a.show();
	system("pause");
	return 0;
}




